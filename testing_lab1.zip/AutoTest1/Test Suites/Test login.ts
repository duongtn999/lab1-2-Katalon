<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test login</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>eb6b242d-844e-44e4-808d-065c52fea063</testSuiteGuid>
   <testCaseLink>
      <guid>1767c950-163f-49c3-8380-34cfbb74628f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC001</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d853e800-8ab7-45dc-b664-f6d85f673f47</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC002</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6361ef23-ae18-4c78-bfa5-22f75bf36dc5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC003</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>407664bc-2355-41be-b958-3cf8055a2c08</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC004</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a0c45ca0-eb66-4620-a3b7-e4b776c11f8d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC005</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
